
This is homework 1 of algorithm.

I only accept one file ,"algo_hw1.hpp".

I will use autotest tool to judge your grade.

First, you need to change the student_id;

Second, implement the function to be correct answer.

If there is any wrong in the examples, please tell me.